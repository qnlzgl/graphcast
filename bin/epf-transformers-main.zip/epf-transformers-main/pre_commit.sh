black .
mypy --cache-dir=/dev/null .
